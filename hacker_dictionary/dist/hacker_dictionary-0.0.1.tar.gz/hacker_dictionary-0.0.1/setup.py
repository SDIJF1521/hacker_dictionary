from setuptools import setup

setup(name='hacker_dictionary',
      version='0.0.1',
      description='string to date',
      author='YGXB',
      author_email='839682307@qq.com',
      license='MIT',
      packages=['hacker_dictionary'])